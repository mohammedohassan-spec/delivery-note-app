
import express from "express";
import multer from "multer";
import XLSX from "xlsx";
import fs from "fs";
import { PDFDocument } from "pdf-lib";
import archiver from "archiver";
import cors from "cors";

const app = express();
app.use(cors());

const upload = multer({ dest: "uploads/" });
const TEMPLATE_PATH = "./templates/delivery-note.pdf";
const OUTPUT_DIR = "./output";

if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR);

async function fillPdf(merchant) {
  const pdfBytes = fs.readFileSync(TEMPLATE_PATH);
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const form = pdfDoc.getForm();

  form.getTextField("merchant_name").setText(merchant.name);
  form.getTextField("address").setText(merchant.address);

  if (merchant.provision === "Food") form.getCheckBox("food").check();
  if (merchant.provision === "Equipment") form.getCheckBox("equipment").check();

  const bytes = await pdfDoc.save();
  const filename = `DeliveryNote_${merchant.name}.pdf`;
  fs.writeFileSync(`${OUTPUT_DIR}/${filename}`, bytes);
  return filename;
}

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const wb = XLSX.readFile(req.file.path);
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet);

    const files = [];
    for (const row of rows) {
      const file = await fillPdf({
        name: row["Merchant Name"],
        address: row["Address"],
        provision: row["Provision Type"]
      });
      files.push(file);
    }

    const zipPath = `${OUTPUT_DIR}/delivery-notes.zip`;
    const output = fs.createWriteStream(zipPath);
    const archive = archiver("zip");

    archive.pipe(output);
    files.forEach(f => archive.file(`${OUTPUT_DIR}/${f}`, { name: f }));
    await archive.finalize();

    res.json({ files, zip: "delivery-notes.zip" });
  } catch (e) {
    res.status(500).json({ error: "Failed to process file" });
  }
});

app.use("/download", express.static(OUTPUT_DIR));
app.listen(3001, () => console.log("Backend running on 3001"));
